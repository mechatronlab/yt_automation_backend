from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import sys
import time
import os
import json
import re
import random
from urllib.parse import urlparse, urlencode, parse_qs

from dotenv import load_dotenv

from selenium.common.exceptions import StaleElementReferenceException

from fivesim_api_handler import FiveSimAPIHandler


def find_gmail_addresses(text):
    if not text:
        return []
    return re.findall(r'[a-zA-Z0-9._%+-]+@(?:gmail|googlemail)\.com', text, re.IGNORECASE)


def extract_emails_via_script(driver):
    """Walk visible text nodes — works better than page_source for dynamic Google UI."""
    try:
        emails = driver.execute_script(
            """
            const found = new Set();
            const re = /[a-zA-Z0-9._%+-]+@(?:gmail|googlemail)\\.com/gi;
            const walk = (root) => {
              if (!root) return;
              if (root.shadowRoot) walk(root.shadowRoot);
              if (root.nodeType === Node.TEXT_NODE) {
                const m = (root.textContent || '').match(re);
                if (m) m.forEach(e => found.add(e.toLowerCase()));
                return;
              }
              for (const child of root.childNodes || []) walk(child);
            };
            walk(document.body);
            return Array.from(found);
            """
        )
        return emails or []
    except Exception:
        return []


def extract_created_email(driver, include_navigation=True):
    """Try to find the new Gmail address from the signed-in browser session."""
    candidates = []

    def collect_from_current_page():
        for text in (driver.page_source, driver.title):
            candidates.extend(find_gmail_addresses(text))
        candidates.extend(extract_emails_via_script(driver))
        for el in driver.find_elements(By.CSS_SELECTOR, "[data-email], [data-identifier]"):
            for attr in ("data-email", "data-identifier"):
                value = el.get_attribute(attr) or ""
                candidates.extend(find_gmail_addresses(value))
        for el in driver.find_elements(By.XPATH, "//*[contains(text(), '@gmail.com') or contains(text(), '@googlemail.com')]"):
            candidates.extend(find_gmail_addresses(el.text or ""))

    collect_from_current_page()

    if include_navigation:
        for url in (
            "https://myaccount.google.com/email",
            "https://myaccount.google.com/personal-info",
            "https://mail.google.com/mail/u/0/#inbox",
            "https://accounts.google.com/",
        ):
            try:
                driver.get(url)
                time.sleep(3)
                collect_from_current_page()
            except Exception:
                pass

    seen = set()
    for email in candidates:
        normalized = email.lower()
        if normalized in seen:
            continue
        seen.add(normalized)
        return normalized

    return None


def complete_oauth_consent(driver, timeout=120):
    """Click through account picker and YouTube permission consent screens."""
    end = time.time() + timeout
    while time.time() < end:
        current = driver.current_url
        if "oauth-callback" in current and "code=" in current:
            return True

        page_l = (driver.page_source or "").lower()

        if click_by_text(
            driver, "Allow", "Continue", "Accept", "Got it", "Confirm", "Next", timeout=2
        ):
            time.sleep(1.5)
            continue

        if "select all" in page_l or "permission" in page_l:
            if click_by_text(driver, "Select all", timeout=2):
                time.sleep(0.5)
                continue

        try:
            for css in ("div[data-email]", "div[data-identifier]", "li.JDAKTe", "div[role='link']"):
                options = driver.find_elements(By.CSS_SELECTOR, css)
                visible = [o for o in options if o.is_displayed()]
                if visible:
                    js_click_el(driver, visible[0])
                    time.sleep(1.5)
                    break
        except Exception:
            pass

        time.sleep(1)

    current = driver.current_url
    return "oauth-callback" in current and "code=" in current


def obtain_oauth_code(driver, email, phone=""):
    """Get Google OAuth authorization code using the logged-in Selenium session."""
    load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
    client_id = os.getenv("GOOGLE_CLIENT_ID")
    port = os.getenv("PORT", "5003")

    if not client_id:
        print("WARNING: GOOGLE_CLIENT_ID missing — cannot obtain OAuth tokens")
        return None

    redirect_uri = f"http://127.0.0.1:{port}/api/auth/google/oauth-callback"
    scopes = (
        "email profile "
        "https://www.googleapis.com/auth/youtube.readonly "
        "https://www.googleapis.com/auth/youtube.upload "
        "https://www.googleapis.com/auth/youtube.force-ssl"
    )

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": scopes,
        "access_type": "offline",
        "prompt": "consent",
        "include_granted_scopes": "true",
    }
    login_hint = (email or phone or "").strip()
    if login_hint:
        params["login_hint"] = login_hint

    auth_url = "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(params)
    print("Opening Google OAuth consent (YouTube permissions — same as Connect Account)...")
    driver.get(auth_url)

    if not complete_oauth_consent(driver):
        print("WARNING: OAuth consent timed out — check oauth_consent_timeout.png")
        driver.save_screenshot("oauth_consent_timeout.png")
        return None

    query = parse_qs(urlparse(driver.current_url).query)
    code = (query.get("code") or [None])[0]
    if code:
        print("OAuth authorization code captured (YouTube scopes granted)")
    return code


def is_signup_finished(driver):
    parsed = urlparse(driver.current_url)
    host = parsed.netloc.lower()
    path = parsed.path.lower()
    if host in ("myaccount.google.com", "mail.google.com"):
        return True
    if host == "accounts.google.com" and "/manageaccount" in path:
        return True
    return False


def is_confirmation_page(driver):
    return "signup/confirmation" in urlparse(driver.current_url).path.lower()


def save_created_account(base_dir, account_data):
    account_data["completed"] = True
    with open(os.path.join(base_dir, "last_created_account.json"), "w", encoding="utf-8") as f:
        json.dump(account_data, f, indent=2)

    email = (account_data.get("email") or "").strip()
    phone = (account_data.get("phone") or "").strip()
    password = account_data.get("password") or ""

    with open(os.path.join(base_dir, "account.txt"), "a", encoding="utf-8") as f:
        if email and phone:
            f.write(f"{email} | {phone} | {password}\n")
        elif email:
            f.write(f"{email} | {password}\n")
        elif phone:
            f.write(f"{phone} | {password}\n")
        else:
            f.write(f"unknown | {password}\n")


def js_click_el(driver, element):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    time.sleep(0.3)
    driver.execute_script("arguments[0].click();", element)


def js_click_css(driver, css, timeout=20, retries=3):
    last_error = None
    for _ in range(retries):
        try:
            el = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, css))
            )
            js_click_el(driver, el)
            return el
        except StaleElementReferenceException as exc:
            last_error = exc
            time.sleep(0.5)
    if last_error:
        raise last_error
    raise TimeoutError(f"Element not found: {css}")


def click_by_text(driver, *labels, timeout=8):
    for label in labels:
        xpath = (
            f"//button[contains(normalize-space(.), '{label}')]"
            f" | //span[contains(normalize-space(.), '{label}')]/ancestor::button[1]"
            f" | //div[@role='button'][contains(normalize-space(.), '{label}')]"
        )
        try:
            el = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((By.XPATH, xpath))
            )
            js_click_el(driver, el)
            return True
        except Exception:
            continue
    return False


def click_next(driver):
    if click_by_text(driver, "Next", timeout=5):
        return True
    for css in ("#next button", "button[jsname='LgbsSe']", "[id$='Next'] button"):
        try:
            js_click_css(driver, css, timeout=5)
            return True
        except Exception:
            continue
    return False


def is_email_username_step(driver):
    url = driver.current_url.lower()
    page = driver.page_source.lower()

    # Optional recovery email is NOT the Gmail username step
    if "optionalemail" in url:
        return False

    if any(token in url for token in ("username", "emailsignup", "collectemail", "selectedemail")):
        return True
    if any(token in page for token in (
        "choose your gmail address",
        "create a gmail address",
        "create an email address",
        "create your own gmail address",
        "how you'll sign in",
        "pick a gmail address",
        "create a gmail address for signing in",
    )):
        return True
    for css in ("#username", "input[name='Username']", "input[name='username']"):
        try:
            field = driver.find_element(By.CSS_SELECTOR, css)
            if field.is_displayed():
                return True
        except Exception:
            pass
    return False


def handle_email_username_step(driver, first_name, last_name):
    """Select or create a Gmail address on the post-SMS username step."""
    time.sleep(2)
    print("Post opt-in URL:", driver.current_url)
    print("Post opt-in title:", driver.title)
    driver.save_screenshot("after_optin.png")

    if not is_email_username_step(driver):
        print("No email/username step detected — continuing")
        return False

    print("Detected email/username step")

    # Prefer Google's first suggested address (radio / list item)
    suggestion_selectors = (
        "div[role='radio']",
        "input[type='radio']",
        "ul[role='listbox'] li:first-child",
        "div[data-email]",
        "div[jsname='CeL6Qc']",
        "div[aria-checked='false'][role='radio']",
    )
    selected = False
    for css in suggestion_selectors:
        try:
            options = driver.find_elements(By.CSS_SELECTOR, css)
            visible = [o for o in options if o.is_displayed()]
            if visible:
                js_click_el(driver, visible[0])
                print(f"Selected suggested email via {css}")
                selected = True
                time.sleep(1)
                break
        except Exception:
            continue

    # Otherwise type a custom username
    if not selected:
        username = f"{first_name.lower()}.{last_name.lower()}{int(time.time()) % 100000}"
        for css in ("#username", "input[name='Username']", "input[name='username']"):
            try:
                field = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, css))
                )
                field.clear()
                field.send_keys(username)
                print(f"Entered custom username: {username}")
                selected = True
                time.sleep(1)
                break
            except Exception:
                continue

    if not click_next(driver):
        raise RuntimeError("Could not click Next on email/username step")

    print("Email/username step submitted")
    time.sleep(2)
    driver.save_screenshot("after_email_step.png")
    return True


def is_qr_verification_page(driver):
    url = driver.current_url.lower()
    page = driver.page_source.lower()
    if "mophoneverification" in url or "qrcod" in url:
        return True
    return "scan the qr code" in page or "scan the code with your phone" in page


def click_element_with_text(driver, *needles):
    """Click the first visible button/link whose text contains one of the needles."""
    needles_l = [n.lower() for n in needles]
    for el in driver.find_elements(
        By.XPATH,
        "//button | //a | //div[@role='button'] | //span[@role='link'] | //li[@role='option']",
    ):
        try:
            if not el.is_displayed():
                continue
            text = (el.text or el.get_attribute("aria-label") or "").strip().lower()
            if not text:
                continue
            if any(n in text for n in needles_l):
                js_click_el(driver, el)
                print(f"Clicked: {(el.text or el.get_attribute('aria-label') or '')[:80]}")
                return True
        except Exception:
            continue
    return False


def driver_is_alive(driver):
    try:
        _ = driver.current_url
        return True
    except Exception:
        return False


def is_password_step(driver):
    url = driver.current_url.lower()
    if "signup/password" in url:
        return True
    for sel in ("#passwd input", "input[name='Passwd']", "#Passwd input"):
        try:
            if any(el.is_displayed() for el in driver.find_elements(By.CSS_SELECTOR, sel)):
                return True
        except Exception:
            continue
    return False


def is_sms_code_step(driver):
    try:
        return bool(driver.find_elements(By.CSS_SELECTOR, "#code, input[name='code']"))
    except Exception:
        return False


def fill_password_step(driver, password):
    """Fill password + confirm on the password step (always AFTER phone verification)."""
    if not is_password_step(driver):
        return False

    print("Creating password (final signup step before account is ready)")
    driver.save_screenshot("password_step_before.png")

    passwd_field = None
    for sel in (
        "#passwd input",
        "input[name='Passwd']",
        "#Passwd input",
        "#passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input",
    ):
        try:
            passwd_field = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, sel))
            )
            break
        except Exception:
            continue

    if not passwd_field:
        print("WARNING: Could not find password field")
        return False

    passwd_field.clear()
    passwd_field.send_keys(password)

    for sel in (
        "#confirm-passwd input",
        "input[name='ConfirmPasswd']",
        "#confirm-passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input",
    ):
        try:
            confirm = driver.find_element(By.CSS_SELECTOR, sel)
            if confirm.is_displayed():
                confirm.clear()
                confirm.send_keys(password)
                break
        except Exception:
            continue

    for sel in ("#createpasswordNext button", "#createpasswordNext > div > button"):
        try:
            js_click_css(driver, sel, timeout=5)
            print("Password submitted")
            time.sleep(3)
            driver.save_screenshot("after_password.png")
            return True
        except Exception:
            continue

    click_next(driver)
    time.sleep(3)
    return True


def switch_qr_to_phone_entry(driver):
    """On Google's QR anti-bot page, switch to SMS/phone number verification."""
    if not driver_is_alive(driver):
        print("ERROR: Browser window closed")
        return False
    if not is_qr_verification_page(driver):
        return False

    print("QR verification page detected — looking for phone/SMS option")
    driver.save_screenshot("qr_verification_page.png")

    if click_element_with_text(
        driver,
        "Try another way",
        "More options",
        "Use another method",
        "Verify with your phone",
        "Use your phone",
        "phone number",
        "Text message",
        "SMS",
        "Get a verification code",
    ):
        time.sleep(2)
        driver.save_screenshot("after_qr_alternative.png")

    if find_phone_field(driver):
        return True

    click_element_with_text(
        driver,
        "Text message",
        "SMS",
        "Phone number",
        "Get a verification code sent to your phone",
        "Standard message",
    )
    time.sleep(2)

    if find_phone_field(driver):
        print("Phone input ready after QR alternative")
        return True

    if not driver_is_alive(driver):
        return False

    try:
        for a in driver.find_elements(By.TAG_NAME, "a"):
            try:
                href = (a.get_attribute("href") or "").lower()
                text = (a.text or "").lower()
                if not a.is_displayed():
                    continue
                if any(x in href or x in text for x in ("phone", "sms", "text", "another", "alternative", "mophone")):
                    js_click_el(driver, a)
                    print(f"Clicked link: {a.text[:60] or href[:60]}")
                    time.sleep(2)
                    if find_phone_field(driver):
                        return True
            except Exception:
                continue
    except Exception as exc:
        print(f"QR page link scan failed: {exc}")

    print("WARNING: QR page has no phone/SMS option — Google requires manual QR scan")
    return False


def is_phone_step(driver):
    url = driver.current_url.lower()
    if is_qr_verification_page(driver):
        return False
    if any(token in url for token in ("collectemailphone", "verifyphone", "startmtsmsidv")):
        return True
    if find_phone_field(driver):
        return True
    page = driver.page_source.lower()
    return any(
        phrase in page
        for phrase in (
            "verify your phone",
            "enter a phone",
            "mobile number",
            "what's your phone",
            "your phone number",
        )
    )


def find_phone_field(driver):
    """Find the phone input using multiple Google signup selectors."""
    selectors = [
        (By.ID, "emailPhone"),
        (By.ID, "phoneNumberId"),
        (By.CSS_SELECTOR, "input[type='tel']"),
        (By.CSS_SELECTOR, "input[name='phoneNumber']"),
        (By.CSS_SELECTOR, "input[name='phoneNumberId']"),
        (By.CSS_SELECTOR, "input[autocomplete='tel']"),
        (By.XPATH, "//input[contains(@aria-label, 'phone') or contains(@aria-label, 'Phone')]"),
        (By.XPATH, "//input[contains(@placeholder, 'phone') or contains(@placeholder, 'Phone')]"),
    ]
    for by, sel in selectors:
        try:
            for el in driver.find_elements(by, sel):
                if el.is_displayed() and el.is_enabled():
                    return el
        except Exception:
            continue
    return None


def wait_for_password_step(driver, first_name=None, last_name=None, timeout=90):
    """After phone/SMS, navigate optional steps until password page appears."""
    end = time.time() + timeout
    while time.time() < end:
        if not driver_is_alive(driver):
            return False
        if is_password_step(driver):
            print("Password step reached")
            return True
        if is_email_username_step(driver) and first_name and last_name:
            handle_email_username_step(driver, first_name, last_name)
            time.sleep(2)
            continue
        advance_optional_signup_steps(driver)
        if click_by_text(driver, "Next", "Continue", "Skip", timeout=2):
            time.sleep(2)
            continue
        time.sleep(1.5)
    return is_password_step(driver)


def advance_to_phone_step(driver, first_name=None, last_name=None, timeout=90):
    """After DOB: reach phone input. Flow must be name → DOB → phone → password."""
    end = time.time() + timeout
    qr_attempts = 0
    max_qr_attempts = 2
    driver.save_screenshot("before_phone_step.png")

    while time.time() < end:
        if not driver_is_alive(driver):
            print("ERROR: Browser window was closed during signup")
            return False

        if find_phone_field(driver):
            print("Phone input field found")
            return True

        if is_sms_code_step(driver):
            print("Already on SMS verification step")
            return True

        url = driver.current_url.lower()
        title = driver.title or ""
        print(f"Signup step — URL: {url}")
        print(f"Signup step — title: {title[:120]}")

        # Password must come AFTER phone — do not fill early
        if is_password_step(driver):
            print("ERROR: Google showed password before phone verification.")
            print("Expected order: name → DOB → phone → password.")
            print("Try a fresh 5SIM number, wait a few hours, or use a different network.")
            driver.save_screenshot("password_before_phone.png")
            return False

        # Email before phone (Google sometimes inserts this — handle to reach phone)
        if is_email_username_step(driver) and first_name and last_name:
            print("Email step before phone — selecting Gmail to continue")
            handle_email_username_step(driver, first_name, last_name)
            time.sleep(2)
            continue

        if is_qr_verification_page(driver):
            qr_attempts += 1
            if qr_attempts > max_qr_attempts:
                print("ERROR: Google shows QR-only verification (no phone input available).")
                print("Try again later with a fresh 5SIM number and different IP.")
                driver.save_screenshot("qr_only_blocked.png")
                return False
            if not switch_qr_to_phone_entry(driver):
                time.sleep(2)
            continue

        if not is_qr_verification_page(driver):
            if click_by_text(driver, "Next", "Continue", "Skip", timeout=2):
                time.sleep(2)
                continue

        time.sleep(1.5)

    driver.save_screenshot("phone_step_not_found.png")
    print("ERROR: Phone input not found — check phone_step_not_found.png")
    return False


def click_phone_next(driver):
    selectors = [
        "#collectEmailPhoneNext button",
        "#phoneNumberNext button",
        "#phoneNumberCollect button",
        "#next button",
        "button[jsname='LgbsSe']",
    ]
    for css in selectors:
        try:
            btn = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, css))
            )
            js_click_el(driver, btn)
            return True
        except Exception:
            continue
    return click_by_text(driver, "Next", "Continue", timeout=5)


def is_phone_rejected(driver):
    page_text = driver.page_source.lower()
    return any(
        phrase in page_text
        for phrase in (
            "used too many times",
            "this phone number can't be used",
            "this phone number cannot be used",
            "phone number has been used",
        )
    )


def type_into_phone_field(driver, phone_number, retries=4):
    """Type phone number into the field — retries on stale element."""
    digits = phone_number.strip().replace(" ", "")

    for attempt in range(1, retries + 1):
        field = find_phone_field(driver)
        if not field:
            print(f"Phone field not found (attempt {attempt}/{retries})")
            time.sleep(0.5)
            continue

        try:
            js_click_el(driver, field)
            time.sleep(0.2)

            # Re-find after click (Google re-renders the input)
            field = find_phone_field(driver)
            if not field:
                continue

            select_all_key = Keys.COMMAND if sys.platform == "darwin" else Keys.CONTROL
            ActionChains(driver).click(field).key_down(select_all_key).send_keys("a").key_up(select_all_key).perform()
            time.sleep(0.1)
            ActionChains(driver).send_keys(Keys.DELETE).perform()
            time.sleep(0.2)

            for char in digits:
                ActionChains(driver).send_keys(char).perform()
                time.sleep(0.04)

            time.sleep(0.3)
            print("Entered phone:", digits)
            return True
        except StaleElementReferenceException:
            print(f"Stale phone field — retry {attempt}/{retries}")
            time.sleep(0.5)
        except Exception as exc:
            print(f"Phone typing error (attempt {attempt}): {exc}")
            time.sleep(0.5)

    # Last resort: set value via JavaScript
    try:
        field = find_phone_field(driver)
        if field:
            driver.execute_script(
                """
                const el = arguments[0];
                const val = arguments[1];
                el.focus();
                el.value = val;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                """,
                field,
                digits,
            )
            print("Entered phone via JS:", digits)
            return True
    except Exception as exc:
        print(f"JS phone entry failed: {exc}")

    return False


def submit_phone_number(driver, phone_number, first_name=None, last_name=None):
    """Enter phone on Google signup and submit. Returns True if accepted."""
    if not advance_to_phone_step(driver, first_name, last_name):
        return False

    if is_sms_code_step(driver):
        print("On SMS step already — phone was accepted")
        return True

    if not type_into_phone_field(driver, phone_number):
        driver.save_screenshot("phone_field_missing.png")
        print("ERROR: Could not enter phone number")
        return False

    if not click_phone_next(driver):
        print("ERROR: Could not click Next on phone step")
        driver.save_screenshot("phone_next_missing.png")
        return False

    print("Phone submitted")
    time.sleep(3)

    if is_phone_rejected(driver):
        return False

    # Confirm Google moved to SMS verification page
    try:
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "#code, input[name='code']"))
        )
        print("SMS verification page loaded — waiting for 5SIM code")
        return True
    except Exception:
        driver.save_screenshot("no_sms_page_after_phone.png")
        print("ERROR: Google did not show SMS code page after phone submit")
        print("URL:", driver.current_url)
        return False


def clear_phone_field(driver):
    if not type_into_phone_field(driver, "", retries=2):
        field = find_phone_field(driver)
        if field:
            try:
                field.click()
                time.sleep(0.2)
                field.clear()
            except StaleElementReferenceException:
                pass


def acquire_working_phone(five_sim_handler, driver, first_name=None, last_name=None, max_attempts=5):
    """Try active 5SIM numbers already purchased manually. Never auto-buys."""
    rejected = set()

    for attempt in range(1, max_attempts + 1):
        phone = five_sim_handler.acquire_phone_number(exclude=rejected)
        if not phone:
            if rejected:
                print("\nERROR: All active 5SIM numbers were rejected by Google.")
                print("Buy a new number manually at https://5sim.net (Google / Netherlands), then run again.")
            else:
                print("\nERROR: No active 5SIM number found.")
                print("Buy one manually at https://5sim.net (Google / Netherlands), then run again.")
            return None

        print(f"Using phone (attempt {attempt}): {phone}")

        try:
            accepted = submit_phone_number(driver, phone, first_name, last_name)
        except StaleElementReferenceException:
            print("Stale element during phone submit — retrying once")
            time.sleep(1)
            accepted = submit_phone_number(driver, phone, first_name, last_name)

        if accepted:
            print("Phone number accepted")
            return phone

        if not driver_is_alive(driver):
            print("ERROR: Browser window closed")
            return None

        on_sms = is_sms_code_step(driver)
        if not find_phone_field(driver) and not on_sms:
            print("ERROR: Could not find phone input on Google signup page. Check after_birthday.png")
            driver.save_screenshot("phone_step_failed.png")
            return None

        print(f"Phone number rejected by Google: {phone}")
        rejected.add(phone)
        driver.save_screenshot(f"phone_rejected_{attempt}.png")

        if attempt < max_attempts:
            try:
                clear_phone_field(driver)
            except Exception:
                pass

    print("ERROR: All active 5SIM numbers were rejected by Google.")
    print("Buy a new number manually at https://5sim.net (Google / Netherlands), then run again.")
    return None


def advance_optional_signup_steps(driver):
    """Click through optional steps like recovery-email skip / not-now dialogs."""
    for attempt in range(4):
        time.sleep(1.5)
        url = driver.current_url.lower()
        page = driver.page_source.lower()

        # Password step reached — stop here
        if "password" in url or driver.find_elements(By.CSS_SELECTOR, "#passwd input, input[name='Passwd']"):
            print("Reached password step")
            return

        # Optional recovery email — skip it
        if "optionalemail" in url:
            if click_by_text(driver, "Skip", "Next", "Not now", timeout=3):
                print("Skipped optional recovery email")
                driver.save_screenshot(f"after_optional_skip_{attempt + 1}.png")
                continue

        clicked = click_by_text(
            driver,
            "Skip",
            "Not now",
            "Do this later",
            "Cancel",
            "No thanks",
            timeout=3,
        )
        if clicked:
            print(f"Optional step skipped (attempt {attempt + 1})")
            driver.save_screenshot(f"after_optional_skip_{attempt + 1}.png")
            continue

        # Fallback: first primary action button on footer bar
        for css in (
            "#yDmH0d c-wiz main div.JYXaTc button",
            "main div.JYXaTc.F8PBrb button",
            "main div.JYXaTc button",
        ):
            try:
                buttons = driver.find_elements(By.CSS_SELECTOR, css)
                visible = [b for b in buttons if b.is_displayed()]
                if visible:
                    js_click_el(driver, visible[0])
                    print(f"Clicked footer button via {css}")
                    break
            except Exception:
                continue
        else:
            break


def click_footer_primary(driver):
    for css in (
        "main div.JYXaTc button",
        "c-wiz main div.JYXaTc button",
        "div.JYXaTc.F8PBrb button",
    ):
        try:
            buttons = driver.find_elements(By.CSS_SELECTOR, css)
            visible = [b for b in buttons if b.is_displayed()]
            if visible:
                js_click_el(driver, visible[-1])
                return True
        except StaleElementReferenceException:
            time.sleep(0.5)
            continue
        except Exception:
            continue
    return False


def complete_signup_wizard(driver, max_steps=20):
    """Click through post-password Google signup screens. Returns detected Gmail if found."""
    detected_email = None

    for step in range(1, max_steps + 1):
        time.sleep(1.5)
        url = driver.current_url.lower()
        title = driver.title or ""
        print(f"Signup wizard step {step}: {title} | {url}")

        if is_confirmation_page(driver):
            email = extract_created_email(driver, include_navigation=False)
            if email:
                detected_email = email
                print(f"Found Gmail on confirmation page: {email}")
            driver.save_screenshot("confirmation_page.png")

        if is_signup_finished(driver):
            print("Signup complete — account page reached")
            if not detected_email:
                detected_email = extract_created_email(driver, include_navigation=False)
            return detected_email

        if click_by_text(driver, "I agree", "Agree", "Accept", timeout=3):
            print(f"Clicked agree/accept (step {step})")
            continue

        if click_by_text(driver, "Next", "Continue", timeout=3):
            print(f"Clicked next/continue (step {step})")
            continue

        if click_by_text(driver, "Skip", "Not now", "Do this later", "No thanks", timeout=3):
            print(f"Clicked skip (step {step})")
            continue

        try:
            options = driver.find_elements(
                By.CSS_SELECTOR,
                "div[role='radio'], input[type='radio'], input[type='checkbox']",
            )
            visible = [o for o in options if o.is_displayed()]
            if visible:
                js_click_el(driver, visible[0])
                print(f"Selected first option (step {step})")
                time.sleep(0.5)
                if click_by_text(driver, "Next", "Skip", "Continue", timeout=3):
                    continue
        except StaleElementReferenceException:
            continue

        if click_footer_primary(driver):
            print(f"Clicked footer button (step {step})")
            continue

        driver.save_screenshot(f"signup_stuck_step_{step}.png")
        print("No actionable button found — stopping wizard loop")
        break

    if not detected_email:
        detected_email = extract_created_email(driver, include_navigation=False)

    return detected_email


def pick_random_line(filepath, label):
    """Pick a random non-empty line from a config file."""
    with open(filepath, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
    if not lines:
        print(f"ERROR: No entries in {os.path.basename(filepath)}")
        sys.exit(1)
    choice = random.choice(lines)
    print(f"Picked random {label}: {choice}")
    return choice


def pick_name_or_env(env_key, filepath, label):
    """Use env override when provided, otherwise pick randomly from file."""
    env_val = os.environ.get(env_key, "").strip()
    if env_val:
        print(f"Using selected {label}: {env_val}")
        return env_val
    return pick_random_line(filepath, label)


def main():
    base_dir = os.path.dirname(__file__)

    first_name = pick_name_or_env(
        "SCRIPT_FIRST_NAME", os.path.join(base_dir, "nameFirst.txt"), "first name"
    )
    last_name = pick_name_or_env(
        "SCRIPT_LAST_NAME", os.path.join(base_dir, "nameLast.txt"), "last name"
    )
    password = pick_name_or_env(
        "SCRIPT_PASSWORD", os.path.join(base_dir, "password.txt"), "password"
    )

    birthday_str = pick_name_or_env(
        "SCRIPT_BIRTHDAY", os.path.join(base_dir, "birthday.txt"), "birthday"
    )
    birthday_parts = birthday_str.split()
    if len(birthday_parts) != 3:
        print(f"ERROR: Invalid birthday format (use MM DD YYYY): {birthday_str}")
        sys.exit(1)
    month_str, day_str, year_str = birthday_parts

    five_sim_handler = FiveSimAPIHandler()

    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--lang=en-US")
    options.add_argument(
        "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    )
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options,
    )
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })

    try:
        signin_url = "https://accounts.google.com/signup"
        driver.get(signin_url)
        print("=== STEP 1/5: Name ===")
        print("Opened Google signup page")

        # First name
        print(driver.current_url)
        print(driver.title)
        driver.save_screenshot("debug.png")
        def fill_field(element_id, value):
            field = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.ID, element_id))
            )
            field.click()
            time.sleep(0.2)
            # Select all and delete existing content
            select_all_key = Keys.COMMAND if sys.platform == "darwin" else Keys.CONTROL
            ActionChains(driver).key_down(select_all_key).send_keys('a').key_up(select_all_key).perform()
            time.sleep(0.1)
            ActionChains(driver).send_keys(Keys.DELETE).perform()
            time.sleep(0.2)
            # Type character by character so Google's JS framework registers each keystroke
            for char in value:
                ActionChains(driver).send_keys(char).perform()
                time.sleep(0.05)
            time.sleep(0.3)

        fill_field("firstName", first_name)
        fill_field("lastName", last_name)
        driver.save_screenshot("after_name_typed.png")

        WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#collectNameNext button"))
        ).click()

        print("Name submitted")

        print("=== STEP 2/5: Birthday (DOB) ===")
        time.sleep(2)
        WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.ID, "month"))
        )

        month_dropdown = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#month div[role='combobox'], #month > div > div.VfPpkd-TkwUic > div"))
        )
        month_dropdown.click()
        time.sleep(1)

        month_index = int(month_str)
        month_option_selector = f"#month ul li:nth-child({month_index + 1})"

        WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, month_option_selector))
        ).click()

        driver.find_element(By.ID, "day").send_keys(day_str)
        driver.find_element(By.ID, "year").send_keys(year_str)

        # Gender
        gender_dropdown = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#gender > div > div.VfPpkd-TkwUic > div"))
        )
        gender_dropdown.click()
        time.sleep(1)

        gender_option = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#gender ul li:nth-child(3)"))
        )
        gender_option.click()

        WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#birthdaygenderNext button"))
        ).click()

        print("Birthday and gender submitted")
        driver.save_screenshot("after_birthday.png")

        print("=== STEP 3/5: Phone verification (5SIM) ===")
        active_phone_number = acquire_working_phone(
            five_sim_handler,
            driver,
            first_name=first_name,
            last_name=last_name,
        )
        if not active_phone_number:
            sys.exit(1)

        driver.save_screenshot("after_phone_submit.png")

        active_order_id = (
            getattr(five_sim_handler, "activation_order_id", None)
            or getattr(five_sim_handler, "active_order_id", None)
        )
        print("Using order ID for SMS poll:", active_order_id)

        # Snapshot SMS count now that Google SMS page is open
        sms_count_before = five_sim_handler.get_sms_count(active_order_id)
        print(f"SMS count before poll: {sms_count_before}")

        sms_code = five_sim_handler.get_sms_code(active_order_id, known_count=sms_count_before)

        if not sms_code:
            print("No SMS code received from 5SIM")
            print("TIP: Check 5sim.net — if no SMS arrived, Google may not have sent one.")
            print("     Buy a fresh number and try again, or verify phone was accepted on screen.")
            driver.save_screenshot("no_sms_code.png")
            sys.exit(1)

        # Now find the field (it is definitely rendered by the time we have a code)
        code_field = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#code"))
        )
        code_field.clear()
        code_field.send_keys(sms_code)
        print("Entered SMS code:", sms_code)

        WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#next button"))
        ).click()

        print("SMS code submitted")
        time.sleep(2)

        # Opt-in page (marketing emails)
        try:
            js_click_css(driver, "#optIn button, #optIn > div > button")
        except Exception:
            click_by_text(driver, "Next", "I agree", "Accept")
        print("Opt-in clicked")

        print("=== STEP 4/5: Password (last signup field) ===")
        if not wait_for_password_step(driver, first_name, last_name):
            print("ERROR: Password step not reached after phone verification")
            driver.save_screenshot("password_step_missing.png")
            sys.exit(1)

        if not fill_password_step(driver, password):
            print("ERROR: Could not fill password")
            sys.exit(1)

        # Click through terms, privacy, and final agree screens
        created_email = complete_signup_wizard(driver)
        if not created_email:
            created_email = extract_created_email(driver)

        account_data = {
            "email": created_email or "",
            "phone": active_phone_number,
            "password": password,
            "firstName": first_name,
            "lastName": last_name,
            "name": f"{first_name} {last_name}",
        }
        save_created_account(base_dir, account_data)
        print(f"ACCOUNT_PHONE={active_phone_number}")

        if created_email:
            print(f"ACCOUNT_CREATED email={created_email} phone={active_phone_number}")
            print(f"Account saved: {created_email} | {active_phone_number} | {password}")
        else:
            print(f"WARNING: Gmail address not detected. Phone: {active_phone_number}")
            print(f"Account saved: {active_phone_number} | {password}")

        print("=== STEP 5/5: OAuth login + YouTube permissions → save to database ===")
        try:
            oauth_code = obtain_oauth_code(driver, created_email or "", phone=active_phone_number)
            if oauth_code:
                print(f"OAUTH_CODE={oauth_code}")
                print("OAuth + YouTube permissions granted — backend will save to database")
            else:
                print("WARNING: OAuth code not captured — use Connect Account in the UI")
        except Exception as exc:
            print(f"WARNING: OAuth code capture failed: {exc}")
            driver.save_screenshot("oauth_failed.png")

        driver.save_screenshot("account_created.png")

    finally:
        driver.quit()


if __name__ == "__main__":
    main()